import 'package:flutter/material.dart';

class DockProvider extends ChangeNotifier {
  final List<IconData> _items = [
    Icons.person,
    Icons.message,
    Icons.call,
    Icons.camera,
    Icons.photo,
  ];

  List<IconData> get items => List.unmodifiable(_items);

  void reorderItems(int oldIndex, int newIndex) {
    final item = _items.removeAt(oldIndex);
    if (newIndex >= _items.length) {
      _items.add(item);
    } else {
      _items.insert(newIndex, item);
    }
    notifyListeners();
  }
}
